
document.getElementById('languageSelector').addEventListener('change', function() {
    const selectedLanguage = this.value;
    const contentMap = {
        en: 'Welcome to the NXT Portal!',
        hi: 'एनएक्सटी पोर्टल में आपका स्वागत है!',
        ta: 'NXT போர்டலுக்கு வரவேற்கிறோம்!'
    };
    document.getElementById('languageContent').innerText = contentMap[selectedLanguage];
});

function showTutorial() {
    document.getElementById('tutorialModal').style.display = 'block';
}

function closeTutorial() {
    document.getElementById('tutorialModal').style.display = 'none';
}

document.getElementById('feedbackForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Thank you for your feedback!');
});
